function soma() {
    let num1 = document.getElementById("quilo").value;
    let num2 = document.getElementById("consumido").value;
    let pago = document.getElementById("pago");
    num1 = parseFloat(num1.replace(",", "."))
    num2 = parseFloat(num2.replace(",", "."))
    let resultado = num1 * num2
    pago.innerHTML = "O valor do KG sairá: "+ resultado.toFixed(2).replace(",", ".");
}