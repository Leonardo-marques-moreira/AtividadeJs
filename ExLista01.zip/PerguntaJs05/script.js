function calcularmaior(){
    var num1 = parseFloat (document.getElementById('num1').value);
    var num2 = parseFloat (document.getElementById('num2').value);

    let resultado;

    if (num1 > num2){
        resultado = 'O maior número é: '+ num1;
    } else if(num1 < num2 ){
        resultado = ' O maior número é: '+ num2;
    } else {
        resultado = 'Os números são iguais: '+ num1;
    }

    document.getElementById('res').innerText = resultado;
}
