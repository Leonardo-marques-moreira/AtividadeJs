function findSmallestValue() {
    let value1 = parseFloat(document.getElementById('value1').value);
    let value2 = parseFloat(document.getElementById('value2').value);
    let value3 = parseFloat(document.getElementById('value3').value);
    let value4 = parseFloat(document.getElementById('value4').value);

    let smallestValue = Math.min(value1, value2, value3, value4);
    document.getElementById('result').innerText = `O menor valor é: ${smallestValue}`;
}
