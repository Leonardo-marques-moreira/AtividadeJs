function checkProduct() {
    let code = document.getElementById('code').value;

    let productName;

    if (code === '001') {
        productName = 'Parafuso';
    } else if (code === '002') {
        productName = 'Porca';
    } else if (code === '003') {
        productName = 'Prego';
    } else {
        productName = 'Diversos';
    }

    document.getElementById('result').innerText = `Produto: ${productName}`;
}
