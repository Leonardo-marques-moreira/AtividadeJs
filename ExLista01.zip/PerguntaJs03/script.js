function reajuste(){
    let saldo = document.getElementById("saldo").value;
    saldo = parseFloat(saldo);
    
    let reajuste = saldo * 1.01;
    
    document.getElementById("res").innerText =
     "Saldo inicial: R$ " + saldo.toFixed(2) + 
     " \nSaldo após o reajuste de 1%: R$ "+ reajuste.toFixed(2);
    }