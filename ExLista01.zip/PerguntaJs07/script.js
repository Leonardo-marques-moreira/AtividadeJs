function checkOdd() {
    let number = parseInt(document.getElementById('number').value);

    let isOdd = number % 2 !== 0;

    if (isOdd) {
        document.getElementById('result').innerText = `O número ${number} é ímpar.`;
    } else {
        document.getElementById('result').innerText = `O número ${number} não é ímpar.`;
    }
}
